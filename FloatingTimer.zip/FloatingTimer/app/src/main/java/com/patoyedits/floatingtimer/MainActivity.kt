package com.patoyedits.floatingtimer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 70, 40, 40)
            setBackgroundColor(0xFF101010.toInt())
        }
        val title = TextView(this).apply {
            text = "Floating Timer"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val desc = TextView(this).apply {
            text = "Cronômetro flutuante minimalista\n\n1 toque: iniciar / pausar\n2 toques rápidos: zerar e reiniciar"
            textSize = 16f
            setTextColor(0xFFCCCCCC.toInt())
            setPadding(0, 24, 0, 32)
        }
        val button = Button(this).apply {
            text = "Ativar cronômetro flutuante"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, TimerOverlayService::class.java))
                    finish()
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        }
        layout.addView(title)
        layout.addView(desc)
        layout.addView(button)
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        // O usuário toca novamente no botão após conceder a permissão.
    }
}
