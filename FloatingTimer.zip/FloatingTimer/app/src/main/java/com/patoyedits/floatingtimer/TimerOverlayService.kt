package com.patoyedits.floatingtimer

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs

class TimerOverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var chip: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var startedAt = 0L
    private var accumulated = 0L
    private var running = false
    private var attached = false
    private var pendingSingle: Runnable? = null
    private var downX = 0
    private var downY = 0
    private var windowX = 0
    private var windowY = 0
    private var dragging = false
    private val tick = object : Runnable {
        override fun run() {
            if (running) {
                render()
                handler.postDelayed(this, 200)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        chip = TextView(this).apply {
            text = "00:00:00"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(22, 13, 22, 13)
            setBackgroundColor(0xEE171717.toInt())
            elevation = 12f
            setOnTouchListener { _, event -> handleTouch(event) }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 180
        }
        wm.addView(chip, params)
        attached = true
    }

    private fun handleTouch(e: MotionEvent): Boolean {
        val p = chip.layoutParams as WindowManager.LayoutParams
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX.toInt()
                downY = e.rawY.toInt()
                windowX = p.x
                windowY = p.y
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX.toInt() - downX
                val dy = e.rawY.toInt() - downY
                if (abs(dx) > 8 || abs(dy) > 8) dragging = true
                if (dragging) {
                    p.x = windowX + dx
                    p.y = windowY + dy
                    wm.updateViewLayout(chip, p)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!dragging) {
                    if (pendingSingle != null) {
                        handler.removeCallbacks(pendingSingle!!)
                        pendingSingle = null
                        resetAndStart()
                    } else {
                        val action = Runnable {
                            pendingSingle = null
                            if (running) pauseTimer() else startTimer()
                        }
                        pendingSingle = action
                        handler.postDelayed(action, 260)
                    }
                }
                return true
            }
        }
        return true
    }

    private fun startTimer() {
        if (!running) {
            startedAt = System.currentTimeMillis()
            running = true
            handler.removeCallbacks(tick)
            handler.post(tick)
        }
    }

    private fun pauseTimer() {
        if (running) {
            accumulated += System.currentTimeMillis() - startedAt
            running = false
            handler.removeCallbacks(tick)
            render()
        }
    }

    private fun resetAndStart() {
        accumulated = 0L
        startedAt = System.currentTimeMillis()
        running = true
        handler.removeCallbacks(tick)
        handler.post(tick)
        render()
    }

    private fun render() {
        val ms = accumulated + if (running) System.currentTimeMillis() - startedAt else 0L
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        chip.text = String.format("%02d:%02d:%02d", h, m, s)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (attached) wm.removeView(chip)
        attached = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
