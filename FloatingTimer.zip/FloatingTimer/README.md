# Floating Timer

Projeto Android nativo em Kotlin. A cápsula flutuante pode ser arrastada pela tela.

## Gestos
- Um toque: iniciar ou pausar.
- Dois toques rápidos: zerar e iniciar novamente.
- Arrastar: reposicionar a cápsula.

## Gerar o APK
1. Abra a pasta `FloatingTimer` no Android Studio.
2. Aguarde a sincronização do Gradle e a instalação dos componentes Android solicitados.
3. No menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Na primeira abertura, toque em **Ativar cronômetro flutuante** e conceda a permissão de aparecer sobre outros apps. Depois, volte ao app e toque no botão novamente.

## Observação
Este ambiente não possui Android SDK/Gradle instalado, então o APK não foi compilado aqui. O código-fonte está pronto para abrir e compilar no Android Studio.
